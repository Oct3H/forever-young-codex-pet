# フォーエバーヤング · Codex 桌宠

青春永驻 / Forever Young，以 Cygames 官方决胜服为依据的 Q 版形象。

## 成品文件

- `package/forever-young/`：可直接安装的宠物目录，内含 `pet.json` 和 `spritesheet.webp`。
- `preview.html`：离线动作预览；可切换动作、深浅背景，手动播放官方语音。
- `动作预览/`：九组动作 GIF、完整动作动画和待机—跳跃—待机过渡动画。
- `official-voice.mp3`：Cygames 官方角色页提供的原始语音，CV 海弓シュリ。
- `CREDITS.md`：角色、素材和制作来源。
- `forever-young-codex-pet.zip` 与 `.zip.sha256`：成品压缩包及 SHA-256 校验值。

九组动作：待机呼吸与眨眼、向右跑、向左跑、挥手、跳跃、失落、等待回应、专注工作、审阅。

## 安装与选择

把 `package/forever-young` 整个目录放入 `${CODEX_HOME}/pets/`；未自定义 CODEX_HOME 时是 `~/.codex/pets/forever-young/`。目录里应直接包含 `pet.json` 和 `spritesheet.webp`，不要多嵌套一层目录。

安装后回到应用的设置 → Pets，点击「Refresh / 刷新」，再选择「フォーエバーヤング」。本项目已在 Codex 中安装并确认刷新后出现在列表。

官方操作说明：https://learn.chatgpt.com/docs/pets

## 语音与格式

随附语音来自官方页面，未剪辑、未合成；预览页面支持手动播放。当前核对的自定义宠物配置没有已确认的音频触发字段，因此未配置桌宠自动发声。

图集为 v1 九状态格式：1536×1872，8 列×9 行，192×208 单元格，57 个有效帧，未使用格子完全透明。当前客户端支持该格式；本包包含九组动作。

图集结构、透明背景、动作逐帧和过渡已通过检查；已安装图集与验证文件逐字节一致。预览展示保存的动画素材。生成提示词、参考素材和完整检查记录保留在本地制作目录中。
