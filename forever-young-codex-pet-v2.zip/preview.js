'use strict';

const target = document.getElementById('pet');
const sprite = document.getElementById('sprite');
const voice = document.getElementById('voice');
const state = document.getElementById('state');
const status = document.getElementById('status');
let paused = false;
let pausedAt = 0;
let pauseOffset = 0;
let imageLoaded = false;
let voiceMessage = '';
let pointer = null;

const controller = new PetInteraction({
  now: () => (paused ? pausedAt : performance.now()) - pauseOffset,
  playVoice: () => {
    voice.pause();
    voice.currentTime = 0;
    voiceMessage = '';
    return voice.play().catch(() => { voiceMessage = '语音未能播放，可使用下方音频控件重试。'; });
  }
});

function pointToPet() {
  if (!pointer || paused) return;
  const bounds = target.getBoundingClientRect();
  controller.point(pointer.x - (bounds.left + bounds.width / 2), pointer.y - (bounds.top + bounds.height / 2));
}

window.addEventListener('pointermove', event => {
  pointer = { x: event.clientX, y: event.clientY };
  pointToPet();
});
window.addEventListener('resize', pointToPet);
window.addEventListener('scroll', pointToPet);
document.documentElement.addEventListener('pointerleave', () => { pointer = null; if (!paused) controller.lookIndex = null; });
target.addEventListener('pointerenter', () => { if (!paused) controller.enter(); });
target.addEventListener('pointerleave', () => controller.leave());
target.addEventListener('click', () => {
  if (paused) return;
  state.value = 'interactive';
  controller.greet();
});
state.addEventListener('change', () => controller.preview(state.value === 'interactive' ? null : Number(state.value)));
document.getElementById('pause').addEventListener('click', event => {
  if (paused) pauseOffset += performance.now() - pausedAt;
  else { pausedAt = performance.now(); voice.pause(); }
  paused = !paused;
  if (!paused) pointToPet();
  event.currentTarget.textContent = paused ? '继续' : '暂停';
});
document.getElementById('theme').addEventListener('click', event => {
  const dark = document.body.classList.toggle('dark');
  event.currentTarget.textContent = dark ? '浅色背景' : '深色背景';
});

const sheet = new Image();
sheet.onload = () => {
  if (sheet.naturalWidth !== 1536 || sheet.naturalHeight !== 2288) {
    status.textContent = '图集不是 v2 格式，请检查安装文件。';
    return;
  }
  imageLoaded = true;
};
sheet.onerror = () => { status.textContent = '图集加载失败，请保留完整成品目录后重试。'; };
sheet.src = 'package/forever-young-v2/spritesheet.webp';

function render() {
  const frame = controller.frame();
  sprite.style.backgroundPosition = `${-192 * frame.column}px ${-208 * frame.row}px`;
  target.dataset.mode = frame.mode;
  target.dataset.row = frame.row;
  target.dataset.column = frame.column;
  target.dataset.jumpCount = controller.jumpCount;
  target.dataset.greetingCount = controller.greetingCount;
  if (imageLoaded) {
    const names = { idle: '待机', looking: '正在看着鼠标', jumping: '跳一次', waving: '挥手打招呼', preview: '动作循环预览' };
    status.textContent = voiceMessage || (paused ? '已暂停' : names[frame.mode]);
  }
  requestAnimationFrame(render);
}
render();
