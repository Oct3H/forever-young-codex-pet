(function (root) {
  'use strict';

  const durations = [
    [280, 110, 110, 140, 140, 320],
    [120, 120, 120, 120, 120, 120, 120, 220],
    [120, 120, 120, 120, 120, 120, 120, 220],
    [140, 140, 140, 280],
    [140, 140, 140, 140, 280],
    [140, 140, 140, 140, 140, 140, 140, 240],
    [150, 150, 150, 150, 150, 260],
    [120, 120, 120, 120, 120, 220],
    [150, 150, 150, 150, 150, 280]
  ];

  function frameAt(row, elapsed) {
    const timing = durations[row];
    let offset = elapsed % timing.reduce((total, value) => total + value, 0);
    for (let column = 0; column < timing.length; column++) {
      if (offset < timing[column]) return column;
      offset -= timing[column];
    }
    return 0;
  }

  class PetInteraction {
    constructor({ now, playVoice }) {
      this.now = now;
      this.playVoice = playVoice;
      this.inside = false;
      this.lookIndex = null;
      this.action = null;
      this.previewRow = null;
      this.started = now();
      this.jumpCount = 0;
      this.greetingCount = 0;
    }

    point(dx, dy) {
      this.lookIndex = Math.hypot(dx, dy) <= 1 ? null :
        Math.round(((Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360) / 22.5) % 16;
    }

    enter() {
      if (this.inside) return;
      this.inside = true;
      if (this.previewRow !== null || this.action !== null) return;
      this.action = { row: 4, started: this.now() };
      this.jumpCount++;
    }

    leave() { this.inside = false; }

    greet() {
      this.previewRow = null;
      this.action = { row: 3, started: this.now() };
      this.greetingCount++;
      return this.playVoice();
    }

    preview(row) {
      this.action = null;
      this.previewRow = row;
      this.started = this.now();
    }

    frame() {
      const time = this.now();
      if (this.action) {
        const { row, started } = this.action;
        const elapsed = time - started;
        const length = durations[row].reduce((total, value) => total + value, 0);
        if (elapsed < length) return { row, column: frameAt(row, elapsed), mode: row === 4 ? 'jumping' : 'waving' };
        this.action = null;
        this.started = time;
      }
      if (this.previewRow !== null) return { row: this.previewRow, column: frameAt(this.previewRow, time - this.started), mode: 'preview' };
      if (this.lookIndex !== null) return { row: 9 + Math.floor(this.lookIndex / 8), column: this.lookIndex % 8, mode: 'looking' };
      return { row: 0, column: frameAt(0, (time - this.started) / 6), mode: 'idle' };
    }
  }

  root.PetInteraction = PetInteraction;
})(globalThis);
